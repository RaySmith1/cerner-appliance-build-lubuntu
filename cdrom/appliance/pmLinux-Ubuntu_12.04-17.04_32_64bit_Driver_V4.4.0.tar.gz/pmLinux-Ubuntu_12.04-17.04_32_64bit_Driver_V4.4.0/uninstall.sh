echo "========================================"
echo "    PenMount XInput Unistall Process    "
echo "========================================"

if [ -f /usr/share/X11/xorg.conf.d/99-input-penmount.conf ]; then
	sudo rm /usr/share/X11/xorg.conf.d/99-input-penmount.conf
fi

if [ -f /usr/share/hal/fdi/policy/20thirdparty/99-x11-penmount.fdi ]; then
	sudo rm /usr/share/hal/fdi/policy/20thirdparty/99-x11-penmount.fdi
fi

if [ -f /usr/lib/xorg/modules/input/penmount_drv.so ]; then
	sudo rm /usr/lib/xorg/modules/input/penmount_drv.so
fi

if [ -f /etc/systemd/system/penmount-serio.service ]; then
	sudo rm /etc/systemd/system/penmount-serio.service
fi

if [ -d /etc/penmount ]; then
	sudo rm -rf /etc/penmount
fi

